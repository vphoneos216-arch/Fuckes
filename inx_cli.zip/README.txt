InvisibleX standalone CLI
==========================
No module, no daemon. Run as root:

  su -c ./inx_cli

Keep this folder's layout as-is (inx_cli, api/, bin/, drivers/ all
together) -- inx_cli finds everything relative to its own location.
