InvisibleX standalone binary
=============================
One binary, no module, no daemon. Run as root:

  su -c ./inx_standalone

Prompts for your key, then the driver, then bar/vol, then runs.
Keep the drivers/ folder next to it if you plan to pick Paradise
-- every other driver option needs no extra files at all.

Driver option "kpm" (Standalone KPM, APatch only):
Keep inx_mem.kpm next to this binary. No superkey setup needed
in the normal case -- it authenticates as "su" automatically if
this binary already has root granted via the APatch app's
Superuser list (the same grant every other driver option here
already needs). Only if that fails does it look for a
"kpm_superkey" field in config.json.
